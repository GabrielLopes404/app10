import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image, Dimensions } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors, FontSizes, Spacing, FontWeights, BorderRadius, Shadows } from '../constants/theme';

const { width } = Dimensions.get('window');
const getCardWidth = () => {
  if (width < 360) return (width - Spacing.md * 3) / 2;
  return (width - Spacing.lg * 3) / 2;
};
const CARD_WIDTH = getCardWidth();

export default function StoreCardCompact({ store, onPress }) {
  return (
    <TouchableOpacity
      style={styles.container}
      activeOpacity={0.9}
      onPress={onPress}
    >
      <View style={styles.imageContainer}>
        <Image
          source={{ uri: store.image }}
          style={styles.image}
          resizeMode="cover"
        />
        
        {store.discount && (
          <View style={styles.discountBadge}>
            <Text style={styles.discountText}>{store.discount}</Text>
          </View>
        )}
        
        <TouchableOpacity style={styles.favoriteButton} activeOpacity={0.8}>
          <Ionicons name="heart" size={16} color={Colors.error} />
        </TouchableOpacity>
      </View>

      <View style={styles.content}>
        <Text style={styles.name} numberOfLines={2}>{store.name}</Text>
        
        <View style={styles.metrics}>
          <View style={styles.metric}>
            <Ionicons name="star" size={12} color={Colors.rating} />
            <Text style={styles.metricText}>{store.rating.toFixed(1)}</Text>
          </View>
          
          <View style={styles.metric}>
            <Ionicons name="location" size={12} color={Colors.textSecondary} />
            <Text style={styles.metricText}>{store.distance} km</Text>
          </View>
        </View>

        <View style={styles.footer}>
          <View style={[
            styles.statusBadge,
            { backgroundColor: store.isOpen ? Colors.successLight : Colors.errorLight }
          ]}>
            <View style={[
              styles.statusDot,
              { backgroundColor: store.isOpen ? Colors.success : Colors.error }
            ]} />
            <Text style={[
              styles.statusText,
              { color: store.isOpen ? Colors.success : Colors.error }
            ]}>
              {store.isOpen ? 'Aberto' : 'Fechado'}
            </Text>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    width: CARD_WIDTH,
    backgroundColor: Colors.backgroundLight,
    borderRadius: BorderRadius.lg,
    marginBottom: Spacing.lg,
    overflow: 'hidden',
    ...Shadows.medium,
  },
  imageContainer: {
    width: '100%',
    height: width < 360 ? 100 : 120,
    backgroundColor: Colors.backgroundGray,
    position: 'relative',
  },
  image: {
    width: '100%',
    height: '100%',
  },
  discountBadge: {
    position: 'absolute',
    top: Spacing.xs,
    left: Spacing.xs,
    backgroundColor: Colors.accent,
    paddingHorizontal: Spacing.xs,
    paddingVertical: 2,
    borderRadius: BorderRadius.xs,
  },
  discountText: {
    fontSize: 9,
    fontWeight: FontWeights.bold,
    color: Colors.textLight,
  },
  favoriteButton: {
    position: 'absolute',
    top: Spacing.xs,
    right: Spacing.xs,
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.9)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  content: {
    padding: width < 360 ? Spacing.xs : Spacing.sm,
  },
  name: {
    fontSize: FontSizes.sm,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
    marginBottom: Spacing.xs,
    height: 32,
  },
  metrics: {
    flexDirection: 'row',
    gap: Spacing.sm,
    marginBottom: Spacing.xs,
  },
  metric: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
  },
  metricText: {
    fontSize: FontSizes.xs,
    color: Colors.textSecondary,
    fontWeight: FontWeights.medium,
  },
  footer: {
    marginTop: Spacing.xs,
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    paddingHorizontal: Spacing.xs,
    paddingVertical: 2,
    borderRadius: BorderRadius.xs,
    gap: 3,
  },
  statusDot: {
    width: 4,
    height: 4,
    borderRadius: 2,
  },
  statusText: {
    fontSize: 9,
    fontWeight: FontWeights.semibold,
  },
});
