import React, { useState } from 'react';
import { View, TextInput, StyleSheet, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, { 
  useAnimatedStyle, 
  withSpring,
  useSharedValue,
  withTiming
} from 'react-native-reanimated';
import { Colors, Spacing, FontSizes, FontWeights, BorderRadius, Shadows } from '../constants/theme';

const SearchBarPremium = ({ onSearch, placeholder = 'Buscar...', onFocus }) => {
  const [query, setQuery] = useState('');
  const [isFocused, setIsFocused] = useState(false);
  const scaleValue = useSharedValue(1);
  const borderWidth = useSharedValue(1);

  const handleFocus = () => {
    setIsFocused(true);
    scaleValue.value = withSpring(1.02, {
      damping: 12,
      stiffness: 200,
    });
    borderWidth.value = withTiming(2, { duration: 200 });
    onFocus && onFocus();
  };

  const handleBlur = () => {
    setIsFocused(false);
    scaleValue.value = withSpring(1);
    borderWidth.value = withTiming(1, { duration: 200 });
  };

  const handleSearch = () => {
    if (query.trim()) {
      onSearch(query);
    }
  };

  const handleClear = () => {
    setQuery('');
  };

  const animatedContainerStyle = useAnimatedStyle(() => {
    return {
      transform: [{ scale: scaleValue.value }],
      borderWidth: borderWidth.value,
    };
  });

  return (
    <View style={styles.container}>
      <Animated.View style={[styles.searchContainer, animatedContainerStyle]}>
        <View style={styles.searchContent}>
          <View style={styles.iconWrapper}>
            <LinearGradient
              colors={isFocused ? Colors.gradientTwilight : [Colors.textSecondary, Colors.textSecondary]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={styles.iconGradient}
            >
              <Ionicons 
                name="search" 
                size={20} 
                color={Colors.textLight} 
              />
            </LinearGradient>
          </View>

          <TextInput
            style={styles.input}
            placeholder={placeholder}
            placeholderTextColor={Colors.textTertiary}
            value={query}
            onChangeText={setQuery}
            onSubmitEditing={handleSearch}
            onFocus={handleFocus}
            onBlur={handleBlur}
            returnKeyType="search"
            autoCapitalize="none"
            autoCorrect={false}
          />

          {query.length > 0 && (
            <TouchableOpacity 
              onPress={handleClear}
              style={styles.clearButton}
              activeOpacity={0.7}
            >
              <View style={styles.clearButtonInner}>
                <Ionicons 
                  name="close-circle" 
                  size={20} 
                  color={Colors.textSecondary} 
                />
              </View>
            </TouchableOpacity>
          )}

          {query.length > 0 && (
            <TouchableOpacity 
              onPress={handleSearch}
              style={styles.searchButton}
              activeOpacity={0.8}
            >
              <LinearGradient
                colors={Colors.gradientTwilight}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={styles.searchButtonGradient}
              >
                <Ionicons 
                  name="arrow-forward" 
                  size={20} 
                  color={Colors.textLight} 
                />
              </LinearGradient>
            </TouchableOpacity>
          )}
        </View>
      </Animated.View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
  },
  searchContainer: {
    backgroundColor: Colors.backgroundCard,
    borderRadius: BorderRadius.xl,
    borderWidth: 1,
    borderColor: Colors.borderLight,
    ...Shadows.small,
  },
  searchContent: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
  },
  iconWrapper: {
    marginRight: Spacing.sm,
  },
  iconGradient: {
    width: 36,
    height: 36,
    borderRadius: BorderRadius.md,
    alignItems: 'center',
    justifyContent: 'center',
  },
  input: {
    flex: 1,
    fontSize: FontSizes.md,
    fontWeight: FontWeights.medium,
    color: Colors.textPrimary,
    paddingVertical: Spacing.xs,
  },
  clearButton: {
    padding: Spacing.xs,
    marginRight: Spacing.xs,
  },
  clearButtonInner: {
    width: 28,
    height: 28,
    alignItems: 'center',
    justifyContent: 'center',
  },
  searchButton: {
    marginLeft: Spacing.xs,
  },
  searchButtonGradient: {
    width: 40,
    height: 40,
    borderRadius: BorderRadius.md,
    alignItems: 'center',
    justifyContent: 'center',
    ...Shadows.colored,
  },
});

export default SearchBarPremium;
